<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class Manufacturer extends Model
{
    public  $table = 'manufacturer';
    //
}
