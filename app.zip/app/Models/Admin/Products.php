<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

class Products extends Model
{
  public  $table = 'h_products';

    //
}
