<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

class Store extends Model
{

    public  $table = 'stores';

    //
}
