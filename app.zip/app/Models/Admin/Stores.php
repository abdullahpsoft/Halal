<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

class Stores extends Model
{

  public  $table = 'stores';

    //
}
