<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

class Requests extends Model
{

  public  $table = 'request_track';

    //
}
