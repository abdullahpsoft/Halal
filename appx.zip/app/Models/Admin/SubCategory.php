<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
  public  $table = 'h_sub_categories';
    //
}
